var miniProxy = require("./lib/MiniProxy.js");

module.exports = miniProxy;